﻿namespace TOMS_M_projekts_RTVSK
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSTART = new System.Windows.Forms.Button();
            this.labelCounter = new System.Windows.Forms.Label();
            this.buttonVAR1 = new System.Windows.Forms.Button();
            this.buttonVAR2 = new System.Windows.Forms.Button();
            this.buttonVAR3 = new System.Windows.Forms.Button();
            this.buttonVAR4 = new System.Windows.Forms.Button();
            this.labelCommand = new System.Windows.Forms.Label();
            this.labelTask = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonSTART
            // 
            this.buttonSTART.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonSTART.Location = new System.Drawing.Point(29, 25);
            this.buttonSTART.Name = "buttonSTART";
            this.buttonSTART.Size = new System.Drawing.Size(128, 46);
            this.buttonSTART.TabIndex = 0;
            this.buttonSTART.Text = "START";
            this.buttonSTART.UseVisualStyleBackColor = true;
            this.buttonSTART.Click += new System.EventHandler(this.buttonSTART_Click);
            // 
            // labelCounter
            // 
            this.labelCounter.AutoSize = true;
            this.labelCounter.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.labelCounter.Location = new System.Drawing.Point(189, 36);
            this.labelCounter.Name = "labelCounter";
            this.labelCounter.Size = new System.Drawing.Size(150, 25);
            this.labelCounter.TabIndex = 1;
            this.labelCounter.Text = "Pareizi: 0 no 0";
            // 
            // buttonVAR1
            // 
            this.buttonVAR1.Enabled = false;
            this.buttonVAR1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonVAR1.Location = new System.Drawing.Point(29, 175);
            this.buttonVAR1.Name = "buttonVAR1";
            this.buttonVAR1.Size = new System.Drawing.Size(437, 46);
            this.buttonVAR1.TabIndex = 0;
            this.buttonVAR1.Text = " ";
            this.buttonVAR1.UseVisualStyleBackColor = true;
            this.buttonVAR1.Click += new System.EventHandler(this.buttonVAR1_Click);
            // 
            // buttonVAR2
            // 
            this.buttonVAR2.Enabled = false;
            this.buttonVAR2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonVAR2.Location = new System.Drawing.Point(29, 227);
            this.buttonVAR2.Name = "buttonVAR2";
            this.buttonVAR2.Size = new System.Drawing.Size(437, 46);
            this.buttonVAR2.TabIndex = 0;
            this.buttonVAR2.Text = " ";
            this.buttonVAR2.UseVisualStyleBackColor = true;
            this.buttonVAR2.Click += new System.EventHandler(this.buttonVAR2_Click);
            // 
            // buttonVAR3
            // 
            this.buttonVAR3.Enabled = false;
            this.buttonVAR3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonVAR3.Location = new System.Drawing.Point(29, 279);
            this.buttonVAR3.Name = "buttonVAR3";
            this.buttonVAR3.Size = new System.Drawing.Size(437, 46);
            this.buttonVAR3.TabIndex = 0;
            this.buttonVAR3.Text = " ";
            this.buttonVAR3.UseVisualStyleBackColor = true;
            this.buttonVAR3.Click += new System.EventHandler(this.buttonVAR3_Click);
            // 
            // buttonVAR4
            // 
            this.buttonVAR4.Enabled = false;
            this.buttonVAR4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonVAR4.Location = new System.Drawing.Point(29, 331);
            this.buttonVAR4.Name = "buttonVAR4";
            this.buttonVAR4.Size = new System.Drawing.Size(437, 46);
            this.buttonVAR4.TabIndex = 0;
            this.buttonVAR4.Text = " ";
            this.buttonVAR4.UseVisualStyleBackColor = true;
            this.buttonVAR4.Click += new System.EventHandler(this.buttonVAR4_Click);
            // 
            // labelCommand
            // 
            this.labelCommand.AutoSize = true;
            this.labelCommand.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.labelCommand.Location = new System.Drawing.Point(33, 98);
            this.labelCommand.Name = "labelCommand";
            this.labelCommand.Size = new System.Drawing.Size(410, 25);
            this.labelCommand.TabIndex = 1;
            this.labelCommand.Text = "Atvēriet vārdnīcas failu, nospiežot START";
            // 
            // labelTask
            // 
            this.labelTask.AutoSize = true;
            this.labelTask.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.labelTask.Location = new System.Drawing.Point(33, 134);
            this.labelTask.Name = "labelTask";
            this.labelTask.Size = new System.Drawing.Size(19, 25);
            this.labelTask.TabIndex = 1;
            this.labelTask.Text = " ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 406);
            this.Controls.Add(this.labelCommand);
            this.Controls.Add(this.labelTask);
            this.Controls.Add(this.labelCounter);
            this.Controls.Add(this.buttonVAR4);
            this.Controls.Add(this.buttonVAR3);
            this.Controls.Add(this.buttonVAR2);
            this.Controls.Add(this.buttonVAR1);
            this.Controls.Add(this.buttonSTART);
            this.Name = "Form1";
            this.Text = "TOMS_M_projekts_RTVSK";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSTART;
        private System.Windows.Forms.Label labelCounter;
        private System.Windows.Forms.Button buttonVAR1;
        private System.Windows.Forms.Button buttonVAR2;
        private System.Windows.Forms.Button buttonVAR3;
        private System.Windows.Forms.Button buttonVAR4;
        private System.Windows.Forms.Label labelCommand;
        private System.Windows.Forms.Label labelTask;
    }
}

